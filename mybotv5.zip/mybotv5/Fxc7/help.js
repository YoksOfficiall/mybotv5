
const help = (prefix, ig, name, uptime, pushname2, user, tanggal, jam) => { 
	return `
	
\`\`\`Follow My Instagram\`\`\`
${ig}

\`\`\`GROUP OFFICIAL\`\`\`
https://chat.whatsapp.com/GcHB3sosWE03OoE55c4yJ7

┏━━━━━❬ *USER ${name}* ❭━━━━━━━⊱
┃╭───────────────────────
┃├➲ \`\`\`Hai\`\`\`👋 *${pushname2}*
┣━━━━━━━━━━━━━━━━━
┃├➲ \`\`\`I am\`\`\` *${name}*
┃╰───────────────────────
┃
┃╭───────────────────────
┃├➲ \`\`\`Total Pengguna:\`\`\` *${user.length} User*
┣━━━━━━━━━━━━━━━━━
┃├➲ \`\`\`Total Donasi:\`\`\` *0%* 🙂
┃╰───────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━━❬ *REGULATION ${name}* ❭━━━━━━━⊱
┃
┣⊱❥ \`\`\`AKTIF\`\`\`: ${kyun(uptime)}
┣⊱❥ \`\`\`JAM\`\`\`: *${jam} WIB*
┣⊱❥ \`\`\`TANGGAL\`\`\`: *${tanggal}*
┣⊱❥ \`\`\`VERSION\`\`\`: *5.0 TERMUX*
┃
┣⊱❥ ❌ *SPAM*
┣⊱❥ ❌ *CALL & VC*
┃ \`\`\`Melanggar??\`\`\` *Banned*
┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━❬ *ABOUT ${name}* ❭━━━━━━⊱
┃╭────────────────────────
┃├⊱❥ *${prefix}request [Mau Req Fitur Apa?]*
┃├⊱❥ *${prefix}kalkulator [12*12]*
┃├⊱❥ *${prefix}report [lapor bug]*
┃├⊱❥ *${prefix}info*
┃├⊱❥ *${prefix}donasi*
┃├⊱❥ *${prefix}owner*
┃├⊱❥ *${prefix}speed*
┃├⊱❥ *${prefix}daftar*
┃├⊱❥ *${prefix}totaluser*
┃├⊱❥ *${prefix}chatlist*
┃├⊱❥ *${prefix}blocklist*
┃├⊱❥ *${prefix}banlist*
┃├⊱❥ *${prefix}bahasa*
┃╰────────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━❬ *MEDIA & DOWNLOAD* ❭━━━━━━━⊱
┃͏͏͏͏͏͏͏͏͏͏͏͏͏͏╭────────────────────────
┃├⊱❥ *${prefix}playmp3 [Monolog-pamungkas]*
┃├⊱❥ *${prefix}fb [link video]*
┃├⊱❥ *${prefix}ytmp3 [link yt]*
┃├⊱❥ *${prefix}ytmp4 [link yt]*
┃├⊱❥ *${prefix}tiktokstalk [username]*
┃├⊱❥ *${prefix}igstalk [bel_abelll19]*
┃├⊱❥ *${prefix}insta [Link]*
┃├⊱❥ *${prefix}ssweb [url]*
┃├⊱❥ *${prefix}url2img [Url]*
┃├⊱❥ *${prefix}tiktok*
┃├⊱❥ *${prefix}fototiktok*
┃├⊱❥ *${prefix}meme*
┃├⊱❥ *${prefix}memeindo*
┃├⊱❥ *${prefix}kbbi*
┃├⊱❥ *${prefix}wait*
┃├⊱❥ *${prefix}trendtwit*
┃╰────────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━━━❬ *CREATOR MENU* ❭━━━━━━⊱
┃╭────────────────────────
┃├⊱❥ *${prefix}stiker*
┃├⊱❥ *${prefix}gifstiker*
┃├⊱❥ *${prefix}toimg*
┃├⊱❥ *${prefix}tomp3*
┃├⊱❥ *${prefix}ocr*
┃╰─────────────────────────
┣━━━━━━━━━━━━━━━━━━━━━━━━❥
┃╭─────────────────────────
┃├⊱❥ *${prefix}imoji [❤️]*
┃├⊱❥ *${prefix}tts [id Haii]*
┃├⊱❥ *${prefix}ttp [YOKS]*
┃├⊱❥ *${prefix}csky [YOKS]*
┃├⊱❥ *${prefix}cwooden [YOKS]*
┃├⊱❥ *${prefix}ccrossfire [YOKS]*
┃├⊱❥ *${prefix}cnaruto [YOKS]*
┃├⊱❥ *${prefix}cgbutton [YOKS]*
┃├⊱❥ *${prefix}csbutton [YOKS]*
┃├⊱❥ *${prefix}cflower [YOKS]*
┃├⊱❥ *${prefix}ctxtneon [YOKS]*
┃├⊱❥ *${prefix}cflame3d [YOKS]*
┃├⊱❥ *${prefix}caglow [YOKS]*
┃├⊱❥ *${prefix}cgneon [YOKS]*
┃├⊱❥ *${prefix}cthunder [YOKS]*
┃├⊱❥ *${prefix}cbokeh [YOKS]*
┃├⊱❥ *${prefix}ctoxic [YOKS]*
┃├⊱❥ *${prefix}cmatrix [YOKS]*
┃├⊱❥ *${prefix}cmusic [YOKS]*
┃├⊱❥ *${prefix}cblood [YOKS]*
┃├⊱❥ *${prefix}cwater [YOKS]*
┃├⊱❥ *${prefix}clava [YOKS]*
┃├⊱❥ *${prefix}cfire [YOKS]*
┃├⊱❥ *${prefix}cholo [YOKS]*
┃├⊱❥ *${prefix}cminion [YOKS]*
┃├⊱❥ *${prefix}cold [YOKS]*
┃├⊱❥ *${prefix}cneon [YOKS]*
┃├⊱❥ *${prefix}csunmory [YOKS]*
┃├⊱❥ *${prefix}cbalon [YOKS]*
┃├⊱❥ *${prefix}cglue3d [YOKS]*
┃├⊱❥ *${prefix}csraved [YOKS]*
┃├⊱❥ *${prefix}cswrite [YOKS]*
┃├⊱❥ *${prefix}cssummer [YOKS]*
┃├⊱❥ *${prefix}ccsky [YOKS]*
┃├⊱❥ *${prefix}ccloud [YOKS]*
┃├⊱❥ *${prefix}crvintage [YOKS]*
┃├⊱❥ *${prefix}cbpink [YOKS]*
┃├⊱❥ *${prefix}ctext3d [YOKS]*
┃╰──────────────────────
┣━━━━━━━━━━━━━━━━━━━━━━━━❥
┃╭────────────────────
┃├⊱❥ *${prefix}cstune3d [YOKS/BOT]*
┃├⊱❥ *${prefix}cspace3d [YOKS/BOT]*
┃├⊱❥ *${prefix}cmarvel [YOKS/BOT]*
┃├⊱❥ *${prefix}cavengers [YOKS/BOT]*
┃├⊱❥ *${prefix}cpubg [YOKS/BOT]*
┃├⊱❥ *${prefix}cglitch [YOKS/BOT]*
┃├⊱❥ *${prefix}cluxury [YOKS]*
┃├⊱❥ *${prefix}cmetal [YOKS/BOT]*
┃├⊱❥ *${prefix}cphlogo [YOKS/BOT]*
┃├⊱❥ *${prefix}quotemaker [tx/wtrmk/tema]*
┃├⊱❥ *${prefix}nulis [nama/kelas/text]*
┃╰────────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━━━━❬ *GRUP ONLY* ❭━━━━━━━━⊱
┃╭────────────────────
┃├⊱❥ *${prefix}modeanime [On/Off]*
┃├⊱❥ *${prefix}naruto*
┃├⊱❥ *${prefix}minato*
┃├⊱❥ *${prefix}boruto*
┃├⊱❥ *${prefix}hinata*
┃├⊱❥ *${prefix}sakura*
┃├⊱❥ *${prefix}sasuke*
┃├⊱❥ *${prefix}kaneki*
┃├⊱❥ *${prefix}toukachan*
┃├⊱❥ *${prefix}rize*
┃├⊱❥ *${prefix}akira*
┃├⊱❥ *${prefix}itori*
┃├⊱❥ *${prefix}kurumi*
┃├⊱❥ *${prefix}miku*
┃├⊱❥ *${prefix}anime*
┃├⊱❥ *${prefix}animecry*
┃├⊱❥ *${prefix}neonime*
┃├⊱❥ *${prefix}animekiss*
┃╰──────────────────────
┣━━━━━━━━━━━━━━━━━━━━━━━━❥
┃╭────────────────────
┃├⊱❥ *${prefix}welcome [On/Off]*
┃├⊱❥ *${prefix}grup [buka/tutup]*
┃├⊱❥ *${prefix}antilink*
┃├⊱❥ *${prefix}ownergrup*
┃├⊱❥ *${prefix}setpp*
┃├⊱❥ *${prefix}infogc*
┃├⊱❥ *${prefix}add*
┃├⊱❥ *${prefix}kick*
┃├⊱❥ *${prefix}promote*
┃├⊱❥ *${prefix}demote*
┃├⊱❥ *${prefix}setname*
┃├⊱❥ *${prefix}setdesc*
┃├⊱❥ *${prefix}linkgrup*
┃├⊱❥ *${prefix}tagme*
┃├⊱❥ *${prefix}hidetag*
┃├⊱❥ *${prefix}tagall*
┃├⊱❥ *${prefix}mentionall*
┃├⊱❥ *${prefix}fitnah*
┃├⊱❥ *${prefix}listadmin*
┃├⊱❥ *${prefix}openanime*
┃├⊱❥ *${prefix}edotense*
┃├⊱❥ *${prefix}kudeta*
┃╰──────────────────────
┣━━━━━━━━━━━━━━━━━━━━━━━━❥
┃╭────────────────────
┃├⊱❥ *${prefix}nsfw [On/Off]*
┃├⊱❥ *${prefix}nsfwloli*
┃├⊱❥ *${prefix}nsfwblowjob*
┃├⊱❥ *${prefix}nsfwneko*
┃├⊱❥ *${prefix}nsfwtrap*
┃├⊱❥ *${prefix}hentai*
┃├⊱❥ *${prefix}indohot*
┃├⊱❥ *${prefix}bokep [stepMoms]*
┃├⊱❥ *${prefix}simih [On/Off]*
┃╰────────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━❬ *OTHER FUN & GAME* ❭━━━━━⊱
┃╭────────────────────────
┃├⊱❥ *${prefix}anjing*
┃├⊱❥ *${prefix}kucing*
┃├⊱❥ *${prefix}testime*
┃├⊱❥ *${prefix}hilih*
┃├⊱❥ *${prefix}say*
┃├⊱❥ *${prefix}apakah*
┃├⊱❥ *${prefix}kapankah*
┃├⊱❥ *${prefix}bisakah*
┃├⊱❥ *${prefix}rate*
┃├⊱❥ *${prefix}watak*
┃├⊱❥ *${prefix}hobby*
┃├⊱❥ *${prefix}infogempa*
┃├⊱❥ *${prefix}infonomor*
┃├⊱❥ *${prefix}quotes*
┃├⊱❥ *${prefix}truth*
┃├⊱❥ *${prefix}dare*
┃├⊱❥ *${prefix}katabijak*
┃├⊱❥ *${prefix}fakta*
┃├⊱❥ *${prefix}darkjokes*
┃├⊱❥ *${prefix}bucin*
┃├⊱❥ *${prefix}pantun*
┃╰────────────────────
┣━━━━━━━━━━━━━━━━━━━━━━━━❥
┃╭────────────────────
┃├⊱❥ *${prefix}translate [en/Apa kabar?]*
┃├⊱❥ *${prefix}gantengcek [Farhan]*
┃├⊱❥ *${prefix}cantikcek [Iriene]*
┃├⊱❥ *${prefix}artinama [Farhan]*
┃├⊱❥ *${prefix}persengay [Topan]*
┃├⊱❥ *${prefix}pbucin [Farhan]*
┃├⊱❥ *${prefix}bpfont [Farhan]*
┃├⊱❥ *${prefix}textstyle [YOKS]*
┃├⊱❥ *${prefix}jadwaltv [antv]*
┃├⊱❥ *${prefix}lirik [melukis senja]*
┃├⊱❥ *${prefix}chord [Melukis senja]*
┃├⊱❥ *${prefix}wiki [Adolf Hitler]*
┃├⊱❥ *${prefix}brainly [pertanyaan]*
┃├⊱❥ *${prefix}resepmasakan [Tempe]*
┃├⊱❥ *${prefix}map [Banyuwangi]*
┃├⊱❥ *${prefix}film [Fast and Farious]*
┃├⊱❥ *${prefix}joox [Monolog Pamungkas]*
┃├⊱❥ *${prefix}smule [Link Video Smule]*
┃├⊱❥ *${prefix}pinterest [gambar kucing]*
┃├⊱❥ *${prefix}infocuaca [Banyuwangi]*
┃├⊱❥ *${prefix}jamdunia [Banyuwangi]*
┃├⊱❥ *${prefix}mimpi [Ular]*
┃├⊱❥ *${prefix}tinyurl [link]*
┃├⊱❥ *${prefix}bitly [link]*
┃╰────────────────────
┣━━━━━━━━━━━━━━━━━━━━━━━━❥
┃╭────────────────────
┃├⊱❥ *${prefix}jadwalsholat [Banyuwangi]*
┃├⊱❥ *${prefix}quran*
┃├⊱❥ *${prefix}quransurah [1]*
┃╰────────────────────
┣━━━━━━━━━━━━━━━━━━━━━━━━❥
┃╭────────────────────
┃├⊱❥ *${prefix}encode64 [string]*
┃├⊱❥ *${prefix}decode64 [encrypt]*
┃╰────────────────────────
┣━━━━━━━━━━━━━━━━━━━━━━━━❥
┃╭────────────────────
┃├⊱❥ *${prefix}spamcall [083xxxxxxxxx]*
┃├⊱❥ *${prefix}spamsms [083xxxxxxxx/jumlah]*
┃├⊱❥ *${prefix}spamgmail [blabla@gmail.com/jumlah]*
┃╰────────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━❬ *OWNER ONLY* ❭━━━━━━━⊱
┃╭──────────────────
┃├⊱❥ *${prefix}bc*
┃├⊱❥ *${prefix}bcgc*
┃├⊱❥ *${prefix}ban*
┃├⊱❥ *${prefix}unban*
┃├⊱❥ *${prefix}block*
┃├⊱❥ *${prefix}unblock*
┃├⊱❥ *${prefix}clearall*
┃├⊱❥ *${prefix}delete*
┃├⊱❥ *${prefix}clone*
┃├⊱❥ *${prefix}getses*
┃├⊱❥ *${prefix}leave*
┃╰────────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━━❬ *SUPPORT ${name}* ❭━━━━━━⊱
┃╭────────────────────────
┃│
┃├➲ *O BOT*
┃├➲ *M. HADI FIRMANSYA*
┃├➲ *DELIA AULIA*
┃├➲ *KEVIN DAVID*
┃├➲ * Hans*
┃╰────────────────────────
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━━━━━❬ *NOTE ${name}* ❭━━━━━━━━━⊱
┃
┣⊱❥ \`\`\`Bot ini belum selesai sepenuhnya\`\`\`
┃ \`\`\`Masih dalam proses pengerjaan\`\`\`
┃ \`\`\`Jadi masih jarang aktif, dan\`\`\`
┃ \`\`\`Maaf Jika Ada Menu Yang Error\`\`\`
┃
┣⊱❥ \`\`\`Jika Lama Harap Ulangi Command\`\`\`
┃
┣⊱❥ *Gunakan Command Tanpa []*
┃
┣⊱❥ \`\`\`Dan Jika Mengalami Error\`\`\`
┃ \`\`\`Harap Lapor Owner Dengan Cara\`\`\`
┃ *${prefix}report* \`\`\`apa pesan errornya\`\`\`
┃
┣⊱❥ \`\`\`Mau Invit Bot?? Donasi Gan,\`\`\`
┃ \`\`\`Kalo Gamau Donasi Follow Ig @bel_abelll19\`\`\`
┃
┣⊱❥ \`\`\`Kalian Bisa Mempublish Quotes Kalian\`\`\`
┃ \`\`\`Jika Minat Hubungi Aja Owner Buat Mempublish\`\`\`
┃ \`\`\`Quotes Kalian,\`\`\`
┃ \`\`\`Dan Makasih Buat Temen" Yg Mau Di Public Quotesnya:)\`\`\`
┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
}
exports.help = help
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik*`
}
