### I'm FXC7BOT<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="27px">
<p align="center">
<a href="https://github.com/FarhanXCode7"><img src="https://raw.githubusercontent.com/FarhanXCode7/termux-bot-wa/main/src/glitchtext.png"></a>
</p>
<br>



<p align="center">
<a href="#"><img title="termux-bot-wa" src="https://img.shields.io/badge/-TERMUX--BOT--WA-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/FarhanXCode7"><img title="Author" src="https://img.shields.io/badge/AUTHOR-FARHAN-orange?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/FarhanXCode7/termux-bot-wa/followers"><img title="Followers" src="https://img.shields.io/github/followers/FarhanXCode7?style=flat-square"></a>
<a href="https://github.com/FarhanXCode7/termux-bot-wa/network/members"><img title="Forks" src="https://img.shields.io/github/forks/FarhanXCode7/termux-bot-wa?style=flat-square"></a>
<a href="https://github.com/FarhanXCode7/termux-bot-wa/watchers"><img title="watchers" src="https://img.shields.io/github/watchers/FarhanXCode7/termux-bot-wa?style=flat-square"></a>

</p>


<details>

<summary>🍙 Help me!</summary>

* [Ovo](08311800241)
* [Pulsa](08311800241)
</details>

## Tools

```bash
> Termux
> WhatsApp
> 2 HandPhone
```

## Install
Follow The Steps Below!

```bash
> termux-setup-storage
(after that tap on permission)
> apt install git -y
> git clone https://github.com/FarhanXCode7/termux-bot-wa
> cd termux-bot-wa
> bash install.sh
```

## Usage

```bash
> npm start
```

## Features

| NEW USER | YES
| :---------------------------------------------: | :-----------: |
|  Register Name And Age|✅|

|  CREATOR  |                                           YES |
| :---------------------------------------------: | :-----------: |
| Sticker Maker|✅|
| Sticker Gif Maker|✅|
| Convert Sticker To Image|✅|
| Convert Video To MP3|✅|
| Black Pink Logo Maker|✅|
| 3D Text Maker|✅|
| Quote Maker|✅|
| Water Maker|✅|
| Fire Text Maker
| Marvel Logo Maker|✅|
| Snow Write Maker|✅|
| Ninja Logo Maker|✅|
| Logo Wolf Maker|✅|
| Logo Wolf Maker2|✅|
| Dan Masih Banyak Lagi|✅|

| MEDIA | YES |
| :-----------------: | :-------: |
| Trend Twit|✅|
| YT Search|✅|

| EDUCATION | YES |
| :-----------------: | :-------: |
| The Meaning Of The Name|✅|
| Text To Sticker|✅|
| Nulis|✅|
| Quotes|✅|

| ASK | YES |
| :-----------------: | :-------: |
| Apakah|✅|
| Kapankah|✅|
| Bisakah|✅|

| DOWNLOADER | YES |
| :-----------------: | :-------: |
| Pinterest Downloader|✅|
| Ytmp3 Downloader|✅|
| Ytmp4 Downloader|✅|
| Joox Downloader|✅|
| Facebook Downloader|✅|

| MEME | YES |
| :-----------------: | :-------: |
| Meme|✅|
| Meme Indo|✅|

| GROUP | YES |
| :-----------------: | :-------: |
| Open Group|✅|
| Link Group|✅|
| info Group|✅|
| Close Group|✅|
| Promote Member|✅|
| Demote Member|✅|
| Hide Tag|✅|
| Tag All Members|✅|
| Add Member|✅|
| Kick Member|✅|
| Show List Admins|✅|
| Leave Group|✅|
| Show Owner Group|✅|
| welcome New Members|✅|
| Nsfw|✅|

| SOUND | YES |
| :-----------------: | :-------: |
| Text To Speach|✅|
| Play|✅|

| MUSIC | YES |
| :-----------------: | :-------: |
| Music Lyrics|✅|
| Chord Guitar|✅|

| ISLAM | YES |
| :-----------------: | :-------: |
| Qur'an|✅|

| STALK | YES |
| :-----------------: | :-------: |
| Instagram Stalk|✅|
| Tiktok Stalk|✅|

| WIBU | YES |
| :-----------------: | :-------: |
| Neonime|✅|
| Pokemon|✅|
| Nekonime|✅|
| Naruto|✅|
| Loli|✅|
| Random Shota|✅|
| Random Waifu|✅|
| Random Anime|✅|
| OTHERS MENU

| FUN | YES |
| :-----------------: | :-------: |
| Kucing|✅|
| Anjing|✅|
| Alay|✅|
| Glitch|✅|
| Game|✅|
| Cek Ganteng|✅|
| Watak|✅|
| Random Hobby|✅|

| INFORMATION | YES |
| :-----------------: | :-------: |
| List Bahasa|✅|
| Information Weather|✅|
| KBBI|✅|
| Fakta|✅|
| Covid|✅|

| 18+ | YES |
| :-----------------: | :-------: |
| Random Hentai|✅|
| NSFW Neko|✅|

| OWNER | YES |
| :-----------------: | :-------: |
| Set Prefix|✅|
| Block Member|✅|
| Broadcast|✅|
| Group Broadcast|✅|
| Clear All Chat|✅|

 TENTANG BOT | YES |
| :-----------------: | :-------: |
| info|✅|
| ChatList|❌|










Dan Kalo Minat Kalian Bisa Tambahkan Quotes Hasil Kalian Di Bot
---


